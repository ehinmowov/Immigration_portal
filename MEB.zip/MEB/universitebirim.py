import requests
import re
import xml.etree.ElementTree as ET
import kodolustur


class BirimAdi:
    pass


BirimAdi = BirimAdi


class BirimAdie:
    pass


BirimAdie = BirimAdie


class OgrenimSure:
    pass


OgrenimSure = OgrenimSure


class OgrenimDili:
    pass


OgrenimDili = OgrenimDili


class BirimStatu:
    pass


BirimStatu = BirimStatu


class BirimId:
    pass


BirimId = BirimId



def universitebirim(BirimId, BirimAdi, BirimAdie, OgrenimDili, OgrenimSure, BirimStatu):
    global response
    global payload
    global url

# headers
    headers = {
            'Content-Type': 'text/xml; charset=utf-8'
                    'SOAPAction: "http://tempuri.org/UniversiteBirim"'

            }

    payload = f"""<?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Header>
    <KullaniciKimlik xmlns="http://tempuri.org/">
      <sUserID>school</sUserID>
      <sEncUserPassword>{kodolustur.kodolustur()}</sEncUserPassword>
    </KullaniciKimlik>
  </soap:Header>
  <soap:Body>
    <UniversiteBirim xmlns="http://tempuri.org/">
      <xsifre>true</xsifre>
      <S1>001006</S1>
      <S2>(({BirimId}))</S2>
      <S3>{BirimAdi}</S3>
      <S4>{BirimAdi}</S4>
      <S5>{BirimId}</S5>
      <S6>{BirimStatu}</S6>
      <S7>{OgrenimDili}</S7>
      <S8></S8>
      <S9></S9>
      <S10></S10>
      <S11>{OgrenimSure}</S11>
      <S12>{BirimAdie}</S12>
    </UniversiteBirim>
  </soap:Body>
</soap:Envelope>"""

    url = "https://yokas.mebnet.net/service.asmx"
    response = requests.request("POST", url, headers=headers, data=payload)

# prints the response
    code = response.text
    status = response

    soap_response = code

# Use regular expression to extract the content of <KodOlusturResult>
    result_match = re.search(r'<UniversiteBirimResult>(.*?)</UniversiteBirimResult>', soap_response)

    if result_match:
        result_string = result_match.group(1)
        print(result_string)



    else:
        print("Element not found in SOAP response.")
        return "None"



#universitebirim("CPD100", "computer", "BirimId", "0", "1", "Aktif")
