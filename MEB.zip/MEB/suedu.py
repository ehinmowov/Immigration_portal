import datetime
import tkinter as tk
from tkinter import *
from tkinter import ttk
import ogrenciekle
from tkinter import messagebox
import universitepage
import su_studentdb

import ogrencisil
global my_tree
global Adi_entry
global Soyadi_entry
global student_number_entry
global kimlik_name
global birim_name
global cinsiyet_name
global passport_entry
global dogum_tarihi_name
global Anne_name
global Baba_name
global telefon_name
global Email_name
global Dogum_Yeri_name
global giris_drop
global Employee_name
global Transfer_button
global adress_name
global Ogr_hakki_name
global OgrHakkiTarihi
global status_drop
global Uyruk_name
global uyruk_drop
global kayitTarihi

global diplomaAdi
global diplomaSoyadi
global Ogrenci_No
global Kimlik
global birimid
global Cinsiyet
global Pasaport
global Dogum_Tarihi
global Anne_adi
global Baba_Adi
global Telefon
global email_address
global Dogum_yeri

global selected_giris
global selected_Uyruk_Code
global kayit_tarihi
global kktc_address
global Ogr_Hakki_Tarihi
global Search

global delete_button
global Update_button

global form_label

def r_r_treeview():
        for records in my_tree.get_children():
            my_tree.delete(records)

def update():
    global values
    global response

    x = my_tree.selection()[0]
    values = my_tree.item(x, 'values')
    text = my_tree.item(x, 'text')
    text_string = str(text)

    diploma_adi_value = diplomaAdi.get()
    diploma_soyadi_value = diplomaSoyadi.get()
    ogrenci_no_value = Ogrenci_No.get()
    kimlik_value = Kimlik.get()
    birim_id_value = birimid.get()
    cinsiyet_value = Cinsiyet.get()
    pasaport_value = Pasaport.get()
    dogum_tarihi_value = Dogum_Tarihi.get()
    anne_adi_value = Anne_adi.get()
    baba_adi_value = Baba_Adi.get()
    telefon_value = Telefon.get()
    email_address_value = email_address.get()
    dogum_yeri_value = Dogum_yeri.get()
    selected_giris_value = selected_giris.get()
    selected_uyruk_code_value = selected_Uyruk_Code.get()
    kayit_tarihi_value = kayit_tarihi.get()
    kktc_address_value = kktc_address.get()
    ogr_hakki_tarihi_value = Ogr_Hakki_Tarihi.get()

    result = ogrenciekle.ogrenciekle(diplomaAdi.get(), diplomaSoyadi.get(), Ogrenci_No.get(), Kimlik.get(), birimid.get(), Cinsiyet.get(), Pasaport.get(),
               Dogum_Tarihi.get(), Anne_adi.get(), Baba_Adi.get(), Telefon.get(), email_address.get(), Dogum_yeri.get(),
                            selected_giris.get(), selected_Uyruk_Code.get(), kayit_tarihi, kktc_address.get(), Ogr_Hakki_Tarihi.get())


    if result == "001-Öğrenci sisteme aktarılmıştır." or\
                result == "002-Öğrencinin bilgileri düzeltilmiştir.":

            response = messagebox.askokcancel("Delete Data",
                                      result
                                          )

            su_studentdb.updateStudent(text_string, diploma_adi_value, diploma_soyadi_value, ogrenci_no_value, kimlik_value,
            birim_id_value, cinsiyet_value, pasaport_value, dogum_tarihi_value,
            anne_adi_value, baba_adi_value, telefon_value, email_address_value,
            dogum_yeri_value, selected_giris_value, selected_uyruk_code_value,
            kayit_tarihi_value, kktc_address_value, ogr_hakki_tarihi_value)


            Adi_entry.delete(0, END)
            Soyadi_entry.delete(0, END)
            student_number_entry.delete(0, END)
            kimlik_name.delete(0, END)
            birim_name.delete(0, END)
            cinsiyet_name.delete(0, END)
            passport_entry.delete(0, END)
            dogum_tarihi_name.delete(0, END)
            Anne_name.delete(0, END)
            Baba_name.delete(0, END)
            telefon_name.delete(0, END)
            Email_name.delete(0, END)
            Dogum_Yeri_name.delete(0, END)
            giris_drop.delete(0, END)
            Employee_name.delete(0, END)
            adress_name.delete(0, END)
            Ogr_hakki_name.delete(0, END)
            OgrHakkiTarihi.delete(0, END)
            status_drop.delete(0, END)
            Uyruk_name.delete(0, END)
            uyruk_drop.delete(0, END)
            kayitTarihi.delete(0, END)


            loadStudents()

    else:
        messagebox.showerror("Error", result)


def getTotalStudents():
    global form_label

    count = su_studentdb.getTotal()
    form_label.configure(text=count)

def search():
    global Search
    global Transfer_button
    global delete_button
    global Update_button

    passport = Search.get()
    result = su_studentdb.search(passport)

    r_r_treeview()
    my_tree.insert(parent='', index='end', iid=result["_id"], text=result["_id"], values=(
                   result.get('student_number_entry'), result.get('Adi_entry'), result.get('Soyadi_entry'), result.get('passport_entry'), result.get('kimlik_name'),
                   result.get('birim_name'), result.get('cinsiyet_name'), result.get('dogum_tarihi_name'), result.get('Anne_name'), result.get('Baba_name'), result.get('telefon_name'),
                            result.get('kayit_tarihi'), "1", result.get('Ogr_Hakki_Tarihi'), "01", result.get('Dogum_Yeri_name'), result.get('giris_drop'), result.get('uyruk_entry'),
                           )
                   )

    Transfer_button['state'] = 'disabled'
    delete_button['state'] = 'disabled'
    Update_button['state'] = 'disabled'









def loadStudents():
    global my_tree

    r_r_treeview()

    for result in su_studentdb.fetchAll():

                            my_tree.insert(parent='', index='end', iid=result.get("_id"), text=result.get("_id"), values=(
                   result.get('student_number_entry'), result.get('Adi_entry'), result.get('Soyadi_entry'), result.get('passport_entry'), result.get('kimlik_name'),
                   result.get('birim_name'), result.get('cinsiyet_name'), result.get('dogum_tarihi_name'), result.get('Anne_name'), result.get('Baba_name'), result.get('telefon_name'),
                            result.get('kayit_tarihi'), "1", result.get('Ogr_Hakki_Tarihi'), "01", result.get('Dogum_Yeri_name'), result.get('giris_drop'), result.get('uyruk_entry'),
                           )
                   )

def deletestudent():
    ogrencisil.ogrencisil

    response = messagebox.askokcancel("Delete Data",
                                      ogrencisil.ogrencisil())



def get_selected_row(event):
    data = my_tree.selection()[0]
    values = my_tree.item(data, 'values')
    Adi_entry.delete(0, END)
    Soyadi_entry.delete(0, END)
    student_number_entry.delete(0, END)
    kimlik_name.delete(0, END)
    birim_name.delete(0, END)
    cinsiyet_name.delete(0, END)
    passport_entry.delete(0, END)
    dogum_tarihi_name.delete(0, END)
    Anne_name.delete(0, END)
    Baba_name.delete(0, END)
    telefon_name.delete(0, END)
    Email_name.delete(0, END)
    Dogum_Yeri_name.delete(0, END)
    giris_drop.delete(0, END)
    Employee_name.delete(0, END)
    adress_name.delete(0, END)
    Ogr_hakki_name.delete(0, END)
    OgrHakkiTarihi.delete(0, END)
    status_drop.delete(0, END)
    Uyruk_name.delete(0, END)
    uyruk_drop.delete(0, END)
    kayitTarihi.delete(0, END)

    Adi_entry.insert(END, values[1])
    Soyadi_entry.insert(END, values[2])
    student_number_entry.insert(END, values[0])
    kimlik_name.insert(END, values[4])
    birim_name.insert(END, values[5])
    cinsiyet_name.insert(END, values[6])
    passport_entry.insert(END, values[3])
    dogum_tarihi_name.insert(END, values[7])
    Anne_name.insert(END, values[8])
    Baba_name.insert(END, values[9])
    telefon_name.insert(END, values[10])
    Email_name.insert(END, values[0])
    Dogum_Yeri_name.insert(END, values[16])
    kayitTarihi.insert(END, values[11])
    giris_drop.insert(END, values[17])
    adress_name.insert(END, values[12])
    Ogr_hakki_name.insert(END, values[13])
    OgrHakkiTarihi.insert(END, values[14])
    status_drop.insert(END, values[15])







    Transfer_button['state'] = 'disabled'
    delete_button['state'] = 'normal'
    Update_button['state'] = 'normal'




count = 0

def transferStudent():

    global diplomaAdi
    global diplomaSoyadi
    global Ogrenci_No
    global Kimlik
    global birimid
    global Cinsiyet
    global Pasaport
    global Dogum_Tarihi
    global Anne_adi
    global Baba_Adi
    global Telefon
    global email_address
    global Dogum_yeri

    global selected_giris
    global selected_Uyruk_Code
    global kayit_tarihi
    global kktc_address
    global Ogr_Hakki_Tarihi

    global Adi_entry
    global Soyadi_entry
    global student_number_entry
    global kimlik_name
    global birim_name
    global cinsiyet_name
    global passport_entry
    global dogum_tarihi_name
    global Anne_name
    global Baba_name
    global telefon_name
    global Email_name
    global Dogum_Yeri_name
    global giris_drop
    global Employee_name
    global Transfer_button
    global adress_name
    global Ogr_hakki_name
    global OgrHakkiTarihi
    global status_drop
    global Uyruk_name
    global uyruk_drop
    global kayitTarihi

    diploma_adi_value = diplomaAdi.get()
    diploma_soyadi_value = diplomaSoyadi.get()
    ogrenci_no_value = Ogrenci_No.get()
    kimlik_value = Kimlik.get()
    birim_id_value = birimid.get()
    cinsiyet_value = Cinsiyet.get()
    pasaport_value = Pasaport.get()
    dogum_tarihi_value = Dogum_Tarihi.get()
    anne_adi_value = Anne_adi.get()
    baba_adi_value = Baba_Adi.get()
    telefon_value = Telefon.get()
    email_address_value = email_address.get()
    dogum_yeri_value = Dogum_yeri.get()
    selected_giris_value = selected_giris.get()
    selected_uyruk_code_value = selected_Uyruk_Code.get()
    kayit_tarihi_value = kayit_tarihi.get()
    kktc_address_value = kktc_address.get()
    ogr_hakki_tarihi_value = Ogr_Hakki_Tarihi.get()



    result = ogrenciekle.ogrenciekle(diplomaAdi.get(), diplomaSoyadi.get(), Ogrenci_No.get(), Kimlik.get(), birimid.get(), Cinsiyet.get(), Pasaport.get(),
               Dogum_Tarihi.get(), Anne_adi.get(), Baba_Adi.get(), Telefon.get(), email_address.get(), Dogum_yeri.get(),
                            selected_giris.get(), selected_Uyruk_Code.get(), kayit_tarihi, kktc_address.get(), Ogr_Hakki_Tarihi.get())

    print(diplomaAdi.get())

    if result == "001-Öğrenci sisteme aktarılmıştır." or\
                result == "002-Öğrencinin bilgileri düzeltilmiştir.":

            response = messagebox.askokcancel("Delete Data",
                                      result
                                          )

            su_studentdb.addStudent(diploma_adi_value, diploma_soyadi_value, ogrenci_no_value, kimlik_value,
        birim_id_value, cinsiyet_value, pasaport_value, dogum_tarihi_value,
        anne_adi_value, baba_adi_value, telefon_value, email_address_value,
        dogum_yeri_value, selected_giris_value, selected_uyruk_code_value,
        kayit_tarihi_value, kktc_address_value, ogr_hakki_tarihi_value)

            Adi_entry.delete(0, END)
            Soyadi_entry.delete(0, END)
            student_number_entry.delete(0, END)
            kimlik_name.delete(0, END)
            birim_name.delete(0, END)
            cinsiyet_name.delete(0, END)
            passport_entry.delete(0, END)
            dogum_tarihi_name.delete(0, END)
            Anne_name.delete(0, END)
            Baba_name.delete(0, END)
            telefon_name.delete(0, END)
            Email_name.delete(0, END)
            Dogum_Yeri_name.delete(0, END)
            giris_drop.delete(0, END)
            Employee_name.delete(0, END)
            adress_name.delete(0, END)
            Ogr_hakki_name.delete(0, END)
            OgrHakkiTarihi.delete(0, END)
            status_drop.delete(0, END)
            Uyruk_name.delete(0, END)
            uyruk_drop.delete(0, END)
            kayitTarihi.delete(0, END)


            loadStudents()



    else:
        messagebox.showerror("Error", result)



    # update_button['state'] = 'disabled'
    # Delete_button['state'] = 'disabled'

    # get_total()


def loadScreen():

    global diplomaAdi
    global diplomaSoyadi
    global Ogrenci_No
    global Kimlik
    global birimid
    global Cinsiyet
    global Pasaport
    global Dogum_Tarihi
    global Anne_adi
    global Baba_Adi
    global Telefon
    global email_address
    global Dogum_yeri

    global selected_giris
    global selected_Uyruk_Code
    global kayit_tarihi
    global kktc_address
    global Ogr_Hakki_Tarihi
    global my_tree

    global Adi_entry
    global Soyadi_entry
    global student_number_entry
    global kimlik_name
    global birim_name
    global cinsiyet_name
    global passport_entry
    global dogum_tarihi_name
    global Anne_name
    global Baba_name
    global telefon_name
    global Email_name
    global Dogum_Yeri_name
    global giris_drop
    global Employee_name
    global Transfer_button
    global delete_button
    global Update_button
    global adress_name
    global Ogr_hakki_name
    global OgrHakkiTarihi
    global status_drop
    global Uyruk_name
    global uyruk_drop
    global kayitTarihi

    global Search

    global form_label

    root = tk.Tk()

    root.title("MEB")
    root.iconbitmap('TRNC-Emblem.ico')
    root.geometry('1460x800')
    root.resizable(False, False)

    style = ttk.Style(root)
    style.theme_use("alt")

# Label for the description of the form
    form_label = tk.Label(root, text="Ogrenci Ekle formu", font=50)
    form_label.grid(row=0, column=0, padx=(50, 0), pady=(50, 50))

# Label and entry field for the Student name
    diplomaAdi = tk.StringVar()
    Adi = tk.Label(root, text='Ogrenci Adi:')
    Adi.grid(row=1, column=0, pady=(0, 0), padx=(0, 300))
    Adi_entry = tk.Entry(root, textvariable=diplomaAdi)
    Adi_entry.grid(row=1, column=0)

# Label and entry field for the Diploma Sur Name
    diplomaSoyadi = tk.StringVar()
    Soyadi = tk.Label(root, text='Ogrenci Soyadi:')
    Soyadi.grid(row=2, column=0, pady=(0, 0), padx=(0, 300))
    Soyadi_entry = tk.Entry(root, textvariable=diplomaSoyadi)
    Soyadi_entry.grid(row=2, column=0)

    # Label and entry field for the passport number
    Pasaport = tk.StringVar()
    passport = tk.Label(root, text='Pasaport:')
    passport.grid(row=3, column=0, pady=(0, 0), padx=(0, 300))
    passport_entry = tk.Entry(root, textvariable=Pasaport)
    passport_entry.grid(row=3, column=0)

# Label and entry field for the student number
    Ogrenci_No = tk.StringVar()
    Employee = tk.Label(root, text='Ogrenci No:')
    Employee.grid(row=4, column=0, pady=(0, 0), padx=(0, 300))
    student_number_entry = tk.Entry(root, textvariable=Ogrenci_No)
    student_number_entry.grid(row=4, column=0)

# Label and entry field for the kimlik number
    Kimlik = tk.StringVar()
    Employee = tk.Label(root, text='kimlik No:')
    Employee.grid(row=5, column=0, pady=(0, 0), padx=(0, 300))
    kimlik_name = tk.Entry(root, textvariable=Kimlik)
    kimlik_name.grid(row=5, column=0)


# Label and entry field for the BirimId
    birimid = tk.StringVar()
    Employee = tk.Label(root, text='Birim Id:')
    Employee.grid(row=1, column=2, pady=(0, 0), padx=(0, 300))
    birim_name = tk.Entry(root, textvariable=birimid)
    birim_name.grid(row=1, column=2)

# Label and entry field for the Cinsiyet
    Cinsiyet = tk.StringVar()
    Employee = tk.Label(root, text='Cinsiyet (K/E):')
    Employee.grid(row=2, column=2, pady=(0, 0), padx=(0, 300))
    cinsiyet_name = tk.Entry(root, textvariable=Cinsiyet)
    cinsiyet_name.grid(row=2, column=2)

    # Label and entry field for the Dogum Tarihi
    Dogum_Tarihi = tk.StringVar()
    Employee = tk.Label(root, text='Dogum Tarihi:')
    Employee.grid(row=3, column=2, pady=(0, 0), padx=(0, 300))
    dogum_tarihi_name = tk.Entry(root, textvariable=Dogum_Tarihi)
    dogum_tarihi_name.grid(row=3, column=2)

    # Label and entry field for the Anne adi
    Anne_adi = tk.StringVar()
    Employee = tk.Label(root, text='Anne Adi:')
    Employee.grid(row=4, column=2, pady=(0, 0), padx=(0, 300))
    Anne_name = tk.Entry(root, textvariable=Anne_adi)
    Anne_name.grid(row=4, column=2)

    # Label and entry field for the Baba Adi
    Baba_Adi = tk.StringVar()
    Employee = tk.Label(root, text='Baba Adi:')
    Employee.grid(row=5, column=2, pady=(0, 0), padx=(0, 300))
    Baba_name = tk.Entry(root, textvariable=Baba_Adi)
    Baba_name.grid(row=5, column=2)

    '----------------------------------------'

    # Label and entry field for the Telefon
    Telefon = tk.StringVar()
    Employee = tk.Label(root, text='Telefon:')
    Employee.grid(row=1, column=3, pady=(0, 0), padx=(0, 300))
    telefon_name = tk.Entry(root, textvariable=Telefon)
    telefon_name.grid(row=1, column=3)

    # Label and entry field for the Email
    email_address = tk.StringVar()
    Employee = tk.Label(root, text='Email:')
    Employee.grid(row=2, column=3, pady=(0, 0), padx=(0, 300))
    Email_name = tk.Entry(root, textvariable=email_address)
    Email_name.grid(row=2, column=3)

    # Label and entry field for the Dogum Yeri
    Dogum_yeri = tk.StringVar()
    Employee = tk.Label(root, text='Dogum Yeri:')
    Employee.grid(row=3, column=3, pady=(0, 0), padx=(0, 300))
    Dogum_Yeri_name = tk.Entry(root, textvariable=Dogum_yeri)
    Dogum_Yeri_name.grid(row=3, column=3)

    Giristuru = ['78']
    # Label and entry field for the Giris Turu
    productS_label = Label(root, text='Giris:')
    productS_label.grid(row=4, column=3, pady=(0, 0), padx=(0, 300))
    selected_giris = tk.StringVar()
    giris_drop = ttk.Combobox(root, textvariable=selected_giris)
    giris_drop['values'] = Giristuru
    giris_drop['state'] = 'readonly'
    giris_drop.grid(row=4, column=3)

    Statu = ['01']
    # Label and entry field for the statu
    productS_label = Label(root, text='Statu:')
    productS_label.grid(row=7, column=2, pady=(0, 0), padx=(0, 300))
    selected_statu = tk.StringVar()
    status_drop = ttk.Combobox(root, textvariable=selected_statu)
    status_drop['values'] = Statu
    status_drop['state'] = 'readonly'
    status_drop.grid(row=7, column=2)

    '----------------------------------------'

    # Label and entry field for the Ogrencilik hakki
    Ogrhakki = tk.StringVar()
    Employee = tk.Label(root, text='Ogr hakki:')
    Employee.grid(row=7, column=0, pady=(0, 0), padx=(0, 300))
    Ogr_hakki_name = tk.Entry(root, textvariable=Ogrhakki)
    Ogr_hakki_name.grid(row=7, column=0)

    # Label and entry field for the Ogr Hakki Tarihi
    Ogr_Hakki_Tarihi = tk.StringVar()
    Employee = tk.Label(root, text='Ogr Hakki Tarihi:')
    Employee.grid(row=6, column=2, pady=(0, 0), padx=(0, 300))
    OgrHakkiTarihi = tk.Entry(root, textvariable=Ogr_Hakki_Tarihi)
    OgrHakkiTarihi.grid(row=6, column=2)

    # Label and entry field for the kktc address
    kktc_address = tk.StringVar()
    Employee = tk.Label(root, text='kktc address:')
    Employee.grid(row=6, column=0, pady=(0, 0), padx=(0, 300))
    adress_name = tk.Entry(root, textvariable=kktc_address)
    adress_name.grid(row=6, column=0)

    # Label and entry field for the Uyruk
    uyruk = tk.StringVar()
    Employee = tk.Label(root, text='Uyruk:')
    Employee.grid(row=5, column=3, pady=(0, 0), padx=(0, 300))
    Uyruk_name = tk.Entry(root, textvariable=uyruk)
    Uyruk_name.grid(row=5, column=3)

    Uyruk_Code = ['1', '2', '3']

    # Label and entry field for the Uyruk Code
    productS_label = Label(root, text='Uyruk Code:')
    productS_label.grid(row=6, column=3, pady=(0, 0), padx=(0, 300))
    selected_Uyruk_Code = tk.StringVar()
    uyruk_drop = ttk.Combobox(root, textvariable=selected_Uyruk_Code)
    uyruk_drop['values'] = Uyruk_Code
    uyruk_drop['state'] = 'readonly'
    uyruk_drop.grid(row=6, column=3)

    # Label and entry field for the kayit Tarihi
    kayit_tarihi = tk.StringVar()
    Employee = tk.Label(root, text='kayit Tarihi:')
    Employee.grid(row=7, column=3, pady=(0, 0), padx=(0, 300))
    kayitTarihi = tk.Entry(root, textvariable=kayit_tarihi)
    kayitTarihi.grid(row=7, column=3)


    # Label and entry field for the Search
    Search = tk.StringVar()
    Employee = tk.Label(root, text='Search:')
    Employee.grid(row=0, column=2, pady=(0, 0), padx=(0, 300))
    Employee_name = tk.Entry(root, textvariable=Search)
    Employee_name.grid(row=0, column=2)

    '----------------------------------------'

    # Open University Button
    department_button = tk.Button(root, text='Universite Birim', width=15, bg='#020202', command=universitepage.uniwindow)
    department_button.grid(row=0, column=4)

    # Update Student
    Update_button = tk.Button(root, text='Bilgileri Güncelle', width=15, bg='#020202', command=update)
    Update_button.grid(row=3, column=4)

    # Delete Student
    delete_button = tk.Button(root, text='Ogrenci Sil', width=15, bg='#020202', command=deletestudent)
    delete_button.grid(row=4, column=4)

    # Send Student
    Transfer_button = tk.Button(root, text='Ogrenci Ekle', width=15, bg='#020202', command=transferStudent)
    Transfer_button.grid(row=5, column=4)

    # Send Student
    search_button = tk.Button(root, text='Search', width=15, bg='#020202', command=search)
    search_button.grid(row=0, column=3, pady=(0, 0), padx=(0, 300))

    # ('OGR NO', 'DIPLOMA ADI', 'DIPLOMA SOYADI', 'PASAPORTNO', 'KIMLIKNO', 'BIRIMID', 'CINSIYET', 'DOGUM TARIHI', 'ANNE ADI', 'BABA ADI', 'TELEFON', 'KAYI TARIHI',
    #   'STATU', 'OGR HAKKI', 'OGR HAKKI TARIHI', 'KKTC ADRS', 'TELEFON', 'EMAIL', 'UYRUK',)
    # Tree-view
    my_tree = ttk.Treeview(root, height=15)
    my_tree['columns'] = (
    'OGR NO', 'DIPLOMA ADI', 'DIPLOMA SOYADI', 'PASAPORTNO', 'KIMLIKNO', 'BIRIMID', 'CINSIYET', 'DOGUM TARIHI', 'ANNE ADI',
    'BABA ADI', 'TELEFON', 'KAYI TARIHI', 'ADRESS', 'OGR HAKKI', 'OGR HAKKI TARIH', 'STATUS', 'DOGUM YERI', 'GIRIS'
    , 'UYURUK CODE')
    # Columns for Tree-View
    my_tree.column("#0", width=40)
    my_tree.column("OGR NO", anchor=W, width=100)
    my_tree.column("DIPLOMA ADI", anchor=W, width=100)
    my_tree.column("DIPLOMA SOYADI", anchor=CENTER, width=90)
    my_tree.column("PASAPORTNO", anchor=CENTER, width=90)
    my_tree.column("KIMLIKNO", anchor=CENTER, width=100)
    my_tree.column("BIRIMID", anchor=CENTER, width=100)
    my_tree.column("CINSIYET", anchor=CENTER, width=100)
    my_tree.column("DOGUM TARIHI", anchor=W, width=100)
    my_tree.column("ANNE ADI", anchor=W, width=100)
    my_tree.column("BABA ADI", anchor=CENTER, width=90)
    my_tree.column("TELEFON", anchor=CENTER, width=90)
    my_tree.column("KAYI TARIHI", anchor=CENTER, width=100)
    my_tree.column("ADRESS", anchor=CENTER, width=0)
    my_tree.column("OGR HAKKI", anchor=CENTER, width=0)
    my_tree.column("OGR HAKKI TARIH", anchor=CENTER, width=0)
    my_tree.column("STATUS", anchor=CENTER, width=0)
    my_tree.column("DOGUM YERI", anchor=CENTER)
    my_tree.column("GIRIS", anchor=CENTER, width=0)
    my_tree.column("UYURUK CODE", anchor=CENTER, width=0)


    # Naming the columns of the tree-view
    first_c = my_tree.heading("#0", text="DBN", anchor=W)
    my_tree.heading("OGR NO", text="OGR NO", anchor=CENTER)
    my_tree.heading("DIPLOMA ADI", text="DIPLOMA ADI", anchor=CENTER)
    my_tree.heading("DIPLOMA SOYADI", text="DIPLOMA SOYADI", anchor=CENTER)
    my_tree.heading("PASAPORTNO", text="PASAPORTNO", anchor=CENTER)
    my_tree.heading("KIMLIKNO", text="KIMLIKNO", anchor=CENTER)
    my_tree.heading("BIRIMID", text="BIRIMID", anchor=CENTER)
    my_tree.heading("CINSIYET", text="CINSIYET", anchor=CENTER)
    my_tree.heading("DOGUM TARIHI", text="DOGUM TARIHI", anchor=CENTER)
    my_tree.heading("ANNE ADI", text="ANNE ADI", anchor=CENTER)
    my_tree.heading("BABA ADI", text="BABA ADI", anchor=CENTER)
    my_tree.heading("TELEFON", text="TELEFON", anchor=CENTER)
    my_tree.heading("KAYI TARIHI", text="KAYI TARIHI", anchor=CENTER)
    my_tree.heading("ADRESS", text="ADRESS", anchor=CENTER)
    my_tree.heading("OGR HAKKI", text="OGR HAKKI", anchor=CENTER)
    my_tree.heading("OGR HAKKI TARIH", text="OGR HAKKI TARIH", anchor=CENTER)
    my_tree.heading("STATUS", text="STATUS", anchor=CENTER)
    my_tree.heading("DOGUM YERI", text="DOGUM YERI", anchor=CENTER)
    my_tree.heading("GIRIS", text="GIRIS", anchor=CENTER)
    my_tree.heading("UYURUK CODE", text="UYURUK CODE", anchor=CENTER)

    my_tree.grid(row=20, column=0, rowspan=6, columnspan=10, padx=(10, 0), pady=(10, 0))

    my_tree.bind('<<TreeviewSelect>>', get_selected_row)

    loadStudents()
    getTotalStudents()

    root.mainloop()


loadScreen()

