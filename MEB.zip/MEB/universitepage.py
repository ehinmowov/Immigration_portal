import datetime
import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import universitebirim
import unibirimdb

global count

global BirimAdi, BirimAdie, BirimId, BirimStatu, OgrDili, OgrSure

count = 0
def uniwindow():

    def r_r_treeview():
        for records in my_tree.get_children():
            my_tree.delete(records)




    def loadBirim():

        r_r_treeview()

        for result in unibirimdb.fetchAll():

                            my_tree.insert(parent='', index='end', iid=result.get("_id"), text=result.get("_id"), values=(
                   result.get('BirimID'), result.get('BirimAdi'), result.get('BirimAdie'), result.get('grenimDili'), result.get('OgrenimSure'),
                   result.get('BirimStatu')),
                   )







    def adduni():




        result = universitebirim.universitebirim(BirimId.get(), BirimAdi.get(), BirimAdie.get(), OgrDili.get(), OgrSure.get(),
                                                 BirimStatu.get(),
                                )



        if result == "Üniversite Birim başarı ile eklenmiştir." or\
                result == "Üniversite Birim başarı ile Düzeltilmiştir.":

            response = messagebox.askokcancel("Delete Data",
                                      result
                                          )


            unibirimdb.addBirim(BirimAdi.get(), BirimAdie.get(), BirimId.get(), OgrDili.get(), OgrSure.get(),
                                BirimStatu.get()
                                )

            loadBirim()

            Birim_ID_entry.delete(0, END)
            Birim_Adi_entry.delete(0, END)
            Brim_Adie_entry.delete(0, END)
            Ogrenim_Dili_entry.delete(0, END)
            Ogrenim_Sure_entry.delete(0, END)
            Birim_Statu_entry.delete(0, END)









        else:
            messagebox.showerror("Error", "An error occurred: ")




    window = tk.Toplevel()
    window.title('Universite Birim')
    #window.geometry('800x700')
    window.resizable(False, False)

    BirimAdi = tk.StringVar()
    Adi = tk.Label(window, text='Birim Adi:')
    Adi.grid(row=1, column=0, pady=(0, 0), padx=(0, 300))
    Birim_Adi_entry = tk.Entry(window, textvariable=BirimAdi)
    Birim_Adi_entry.grid(row=1, column=0)

    BirimAdie = tk.StringVar()
    Adi = tk.Label(window, text='Brim Adi (eng):')
    Adi.grid(row=2, column=0, pady=(0, 0), padx=(0, 300))
    Brim_Adie_entry = tk.Entry(window, textvariable=BirimAdie)
    Brim_Adie_entry.grid(row=2, column=0)

    BirimId = tk.StringVar()
    Adi = tk.Label(window, text='Birim ID:')
    Adi.grid(row=3, column=0, pady=(0, 0), padx=(0, 300))
    Birim_ID_entry = tk.Entry(window, textvariable=BirimId)
    Birim_ID_entry.grid(row=3, column=0)

    BirimStatu = tk.StringVar()
    Adi = tk.Label(window, text='Birim Statu:')
    Adi.grid(row=3, column=1, pady=(0, 0), padx=(0, 300))
    Birim_Statu_entry = tk.Entry(window, textvariable=BirimStatu)
    Birim_Statu_entry.grid(row=3, column=1)

    OgrDili = tk.StringVar()
    Adi = tk.Label(window, text='Ogrenim Dili:')
    Adi.grid(row=1, column=1, pady=(0, 0), padx=(0, 300))
    Ogrenim_Dili_entry = tk.Entry(window, textvariable=OgrDili)
    Ogrenim_Dili_entry.grid(row=1, column=1)

    OgrSure = tk.StringVar()
    Adi = tk.Label(window, text='Ogrenim Sure:')
    Adi.grid(row=2, column=1, pady=(0, 0), padx=(0, 300))
    Ogrenim_Sure_entry = tk.Entry(window, textvariable=OgrSure)
    Ogrenim_Sure_entry.grid(row=2, column=1)





    # Tree-view
    my_tree = ttk.Treeview(window, height=15)
    my_tree['columns'] = ('BIRIM ID', 'BIRIM ADI', 'BIRIM ADI (E)', 'OGRENTIM DILI', 'OGRENTIM SURE')
    # Columns for Tree-View
    my_tree.column("#0", width=40)
    my_tree.column("BIRIM ID", anchor=W, width=200)
    my_tree.column("BIRIM ADI", anchor=W, width=200)
    my_tree.column("BIRIM ADI (E)", anchor=CENTER, width=200)
    my_tree.column("OGRENTIM DILI", anchor=CENTER, width=100)
    my_tree.column("OGRENTIM SURE", anchor=CENTER, width=100)
    # Naming the columns of the tree-view
    first_c = my_tree.heading("#0", text="DBN", anchor=W)
    my_tree.heading("BIRIM ID", text="BIRIM ID", anchor=CENTER)
    my_tree.heading("BIRIM ADI", text="BIRIM ADI", anchor=CENTER)
    my_tree.heading("BIRIM ADI (E)", text="BIRIM ADI (E)", anchor=CENTER)
    my_tree.heading("OGRENTIM DILI", text="OGRENTIM DILI", anchor=CENTER)
    my_tree.heading("OGRENTIM SURE", text="OGRENTIM SURE", anchor=CENTER)

    my_tree.grid(row=5, column=0, rowspan=6, columnspan=7, padx=(25, 0), pady=(30, 0))

    birim = tk.Button(window, text='Birim Ekle', command=adduni)
    birim.grid(row=1, column=4, pady=(10, 0))

    loadBirim()


    window.mainloop()
