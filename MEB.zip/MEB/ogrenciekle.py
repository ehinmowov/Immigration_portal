import requests
import re
import xml.etree.ElementTree as ET
import kodolustur


def ogrenciekle(Adi_entry, Soyadi_entry, student_number_entry, kimlik_name, birim_name, cinsiyet_name, passport_entry,
                dogum_tarihi_name, Anne_name, Baba_name, telefon_name, Email_name, Dogum_Yeri_name, giris_drop,
                uyruk_entry,
                kayit_tarihi, kktc_address, Ogr_Hakki_Tarihi):
    global response
    global payload
    global url
    global result_string

    # headers
    headers = {
        'Content-Type': 'text/xml; charset=utf-8'
                        'SOAPAction: "http://tempuri.org/ogrenciekle"'
    }

    payload = f"""<?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Header>
    <KullaniciKimlik xmlns="http://tempuri.org/">
      <sUserID>school</sUserID>
      <sEncUserPassword>{kodolustur.kodolustur()}</sEncUserPassword>
    </KullaniciKimlik>
  </soap:Header>
  <soap:Body>
    <ogrenciekle xmlns="http://tempuri.org/">
      <xsifre>true</xsifre>
      <suniversiteid>001006</suniversiteid>
      <skimlikno>{kimlik_name}</skimlikno>
      <spasaportno>{passport_entry}</spasaportno>
      <suyruk>{uyruk_entry}</suyruk>
      <skangrubu>0</skangrubu>
      <sbirimid>{birim_name}</sbirimid>
      <sgiristuru>{giris_drop}</sgiristuru>
      <sgirispuan></sgirispuan>
      <spuanturu></spuanturu>
      <sayrilmaneden></sayrilmaneden>
      <ssinif>2</ssinif>
      <sogrhakki>1</sogrhakki>
      <shazirlik>3</shazirlik>
      <sayrilmatar></sayrilmatar>
      <skayittarihi>{kayit_tarihi}</skayittarihi>
      <sogrhaktarih>{Ogr_Hakki_Tarihi}</sogrhaktarih>
      <sogrstatu>01</sogrstatu>
      <sdiplomano></sdiplomano>
      <sdiplomanotu>0,00</sdiplomanotu>
      <saktifdonem></saktifdonem>
      <sdiplomanotsistem>4</sdiplomanotsistem>
      <sgenelnotortalama>0,00</sgenelnotortalama>
      <sdiplomaadi>{Adi_entry}</sdiplomaadi>
      <sdiplomasoyadi>{Soyadi_entry}</sdiplomasoyadi>
      <sogrno>{student_number_entry}</sogrno>
      <sdiplomatur></sdiplomatur>
      <shazirliksayi></shazirliksayi>
      <skktcadres>{kktc_address}</skktcadres>
      <sanneadi>{Anne_name}</sanneadi>
      <sbabaadi>{Baba_name}</sbabaadi>
      <stelefonno>{telefon_name}</stelefonno>
      <scinsiyet>{cinsiyet_name}</scinsiyet>
      <sdogumtarihi>{dogum_tarihi_name}</sdogumtarihi>
      <sdogumyeri>{Dogum_Yeri_name}</sdogumyeri>
      <sbolumyili>1</sbolumyili>
      <sdersyili>1</sdersyili>
      <ssom></ssom>
      <semail>{Email_name}</semail>
      <suyrugu></suyrugu>
    </ogrenciekle>
  </soap:Body>
</soap:Envelope>"""

    url = "https://yokas.mebnet.net/service.asmx"
    response = requests.request("POST", url, headers=headers, data=payload)

    # prints the response
    code = response.text
    status = response

    soap_response = code

    # Use regular expression to extract the content of <KodOlusturResult>
    result_match = re.search(r'<ogrenciekleResult>(.*?)</ogrenciekleResult>', soap_response)

    if result_match:
        result_string = result_match.group(1)
        return result_string

    else:
        print("Element not found in SOAP response.")


#ogrenciekle("Adi", "Adi", "11111", "111111", "CPD100", "K", "11111111",
            #"1997-11-11", "Adientry", "Adientry", "543656546457", "Adi@gmail.com", "entry", 1, 3,
            #"1997-11-11", "Here", 1997-11-11)
