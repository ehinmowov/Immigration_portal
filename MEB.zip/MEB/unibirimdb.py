from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
global uri

def addBirim(BirimAdi, BirimAdie, BirimID, OgrenimDili, OgrenimSure, BirimStatu):

    uri = "mongodb+srv://victor:ehinMOWOc4@suedu.qiqlvff.mongodb.net/?retryWrites=true&w=majority"
# Create a new client and connect to the server
    client = MongoClient(uri, server_api=ServerApi('1'))
# Send a ping to confirm a successful connection

    db = client["suedu"]
    collection = db["departments"]

    Post = {"BirimAdi":BirimAdi, "BirimAdie":BirimAdie,"BirimID":BirimID,"OgrenimDili":OgrenimDili,"OgrenimSure":OgrenimSure,"BirimStatu":BirimStatu}

    collection.insert_one(Post)



def fetchAll():

    uri = "mongodb+srv://victor:ehinMOWOc4@suedu.qiqlvff.mongodb.net/?retryWrites=true&w=majority"
# Create a new client and connect to the server
    client = MongoClient(uri, server_api=ServerApi('1'))
# Send a ping to confirm a successful connection
    # to find an entry

    db = client["suedu"]
    collection = db["departments"]

    results = collection.find({})

    return results



fetchAll()



# to find an entry

#results = collection.find({"passport_entry":x})
#for result in results:
   #     print(result)

    #    passport = result["passport_entry"]


# to find an entry from a table click to insert in the entry fields
# This will return ony the entry with that id,then we can then perform an update or a delete action
#id = 0
#results = collection.find({"passport_entry":x})
#for result in results:
     #   print(result)

      #  passport = result["_id":id]


# to delete entry from DB
#results = collection.delete_one({"_id":id})

# to update information on DB
#results = collection.update_one({"_id":id}, {"$set" : {"Adi_entry":x, "Soyadi_entry":x,"student_number_entry":x,"kimlik_name":x,"birim_name":x,"cinsiyet_name":x,"passport_entry":x,"dogum_tarihi_name":x,
 #       "Anne_name":x,"Baba_name":x,"telefon_name":x,"Email_name":x,"Dogum_Yeri_name":x,"giris_drop":x,}})

# to count all students
#post_count = collection.count_documents({})
#print(post_count)
