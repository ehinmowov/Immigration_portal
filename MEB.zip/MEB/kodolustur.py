import requests
import re
import xml.etree.ElementTree as ET

def kodolustur():
    global response
    global payload
    global url
    global result_string

    return result_string
# headers
headers = {
	'Content-Type': 'text/xml; charset=utf-8'
    'SOAPAction: "http://tempuri.org/KodOlustur"'
}

payload = """<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Header>
    <KullaniciKimlik xmlns="http://tempuri.org/">
      <sUserID>school</sUserID>
      <sEncUserPassword>12345</sEncUserPassword>
    </KullaniciKimlik>
  </soap:Header>
  <soap:Body>
    <KodOlustur xmlns="http://tempuri.org/" />
  </soap:Body>
</soap:Envelope>"""

url = "https://yokas.mebnet.net/service.asmx"
response = requests.request("POST", url, headers=headers, data=payload)

# prints the response
code = response.text
status = response
#print(status)

soap_response = code
#print(soap_response)


# Use regular expression to extract the content of <KodOlusturResult>
result_match = re.search(r'<KodOlusturResult>(.*?)</KodOlusturResult>', soap_response)

if result_match:
    result_string = result_match.group(1)
    #print(result_string)
else:
    print("Element not found in SOAP response.")


