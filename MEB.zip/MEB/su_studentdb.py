from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi


global collection


def addStudent(_id, Adi_entry, Soyadi_entry, student_number_entry, kimlik_name, birim_name, cinsiyet_name, passport_entry,
               dogum_tarihi_name, Anne_name, Baba_name, telefon_name, Email_name, Dogum_Yeri_name, giris_drop, uyruk_entry,
               kayit_tarihi, kktc_address, Ogr_Hakki_Tarihi):

    uri = "mongodb+srv://victor:ehinMOWOc4@suedu.qiqlvff.mongodb.net/?retryWrites=true&w=majority"
# Create a new client and connect to the server
    client = MongoClient(uri, server_api=ServerApi('1'))
# Send a ping to confirm a successful connection

    db = client["suedu"]
    collection = db["students"]

    Post = {"Adi_entry":Adi_entry, "Soyadi_entry":Soyadi_entry,"student_number_entry":student_number_entry,
            "kimlik_name":kimlik_name,"birim_name":birim_name,"cinsiyet_name":cinsiyet_name,"passport_entry":passport_entry,
            "dogum_tarihi_name":dogum_tarihi_name, "Anne_name":Anne_name,"Baba_name":Baba_name,"telefon_name":telefon_name,
            "Email_name":Email_name,"Dogum_Yeri_name":Dogum_Yeri_name,"giris_drop":giris_drop, "uyruk_entry":uyruk_entry,
            "kayit_tarihi":kayit_tarihi, "kktc_address":kktc_address, "Ogr_Hakki_Tarihi":Ogr_Hakki_Tarihi}

    collection.insert_one(Post)


def fetchStudent(passport_entry):

    uri = "mongodb+srv://victor:ehinMOWOc4@suedu.qiqlvff.mongodb.net/?retryWrites=true&w=majority"
# Create a new client and connect to the server
    client = MongoClient(uri, server_api=ServerApi('1'))
# Send a ping to confirm a successful connection
    # to find an entry

    db = client["suedu"]
    collection = db["students"]

    results = collection.find({"passport_entry":passport_entry})

    return results



def fetchAll():

    uri = "mongodb+srv://victor:ehinMOWOc4@suedu.qiqlvff.mongodb.net/?retryWrites=true&w=majority"
# Create a new client and connect to the server
    client = MongoClient(uri, server_api=ServerApi('1'))
# Send a ping to confirm a successful connection
    # to find an entry

    db = client["suedu"]
    collection = db["students"]

    results = collection.find({})

    return results


def updateStudent(_id, Adi_entry, Soyadi_entry, student_number_entry, kimlik_name, birim_name, cinsiyet_name, passport_entry,
               dogum_tarihi_name, Anne_name, Baba_name, telefon_name, Email_name, Dogum_Yeri_name, giris_drop, uyruk_entry,
               kayit_tarihi, kktc_address, Ogr_Hakki_Tarihi):

    global collection
    global update_query

    uri = "mongodb+srv://victor:ehinMOWOc4@suedu.qiqlvff.mongodb.net/?retryWrites=true&w=majority"
# Create a new client and connect to the server
    client = MongoClient(uri, server_api=ServerApi('1'))
# Send a ping to confirm a successful connection
    # to find an entry

    db = client["suedu"]
    collection = db["students"]

    update_query = {
        "$set": {
            "Adi_entry": Adi_entry,
            "Soyadi_entry": Soyadi_entry,
            "student_number_entry": student_number_entry,
            "kimlik_name": kimlik_name,
            "birim_name": birim_name,
            "cinsiyet_name": cinsiyet_name,
            "passport_entry": passport_entry,
            "dogum_tarihi_name": dogum_tarihi_name,
            "Anne_name": Anne_name,
            "Baba_name": Baba_name,
            "telefon_name": telefon_name,
            "Email_name": Email_name,
            "Dogum_Yeri_name": Dogum_Yeri_name,
            "giris_drop": giris_drop,
            "uyruk_entry": uyruk_entry,
            "kayit_tarihi": kayit_tarihi,
            "kktc_address": kktc_address,
            "Ogr_Hakki_Tarihi": Ogr_Hakki_Tarihi
        }
    }

    try:
        # Use update_one to update the document with the specified id
        result = collection.update_one({"_id": _id}, update_query)

        if result.modified_count > 0:
            return "002-Öğrencinin bilgileri düzeltilmiştir."
        else:
            return "003-Öğrenci bulunamadı veya güncelleme yapılmadı."

    except Exception as e:
        # Handle exceptions
        return str(e)

def search(passport_entry):
    global collection

    uri = "mongodb+srv://victor:ehinMOWOc4@suedu.qiqlvff.mongodb.net/?retryWrites=true&w=majority"
# Create a new client and connect to the server
    client = MongoClient(uri, server_api=ServerApi('1'))
# Send a ping to confirm a successful connection
    # to find an entry

    db = client["suedu"]
    collection = db["students"]
# to find an entry from a table click to insert in the entry fields
# This will return ony the entry with that id,then we can then perform an update or a delete action

    results = collection.find({"passport_entry": passport_entry})
    for result in results:
        return result



def getTotal():
    global collection


    uri = "mongodb+srv://victor:ehinMOWOc4@suedu.qiqlvff.mongodb.net/?retryWrites=true&w=majority"
# Create a new client and connect to the server
    client = MongoClient(uri, server_api=ServerApi('1'))
# Send a ping to confirm a successful connection
    # to find an entry

    db = client["suedu"]
    collection = db["students"]

    post_count = collection.count_documents({})
    return post_count





# to find an entry from a table click to insert in the entry fields
# This will return ony the entry with that id,then we can then perform an update or a delete action
#id = 0
#results = collection.find({"passport_entry":x})
#for result in results:
       # print(result)

       # passport = result["_id":id]


# to delete entry from DB
#results = collection.delete_one({"_id":id})

# to update information on DB
#results = collection.update_one({"_id":id}, {"$set" : {"Adi_entry":x, "Soyadi_entry":x,"student_number_entry":x,"kimlik_name":x,"birim_name":x,"cinsiyet_name":x,"passport_entry":x,"dogum_tarihi_name":x,
       # "Anne_name":x,"Baba_name":x,"telefon_name":x,"Email_name":x,"Dogum_Yeri_name":x,"giris_drop":x,}})

# to count all students
#post_count = collection.count_documents({})
#print(post_count)

updateStudent('650d9901d0957d5a3920fe34', "Adi_entry", "Adi_entry", "Adi_entry", "Adi_entry", "Adi_entry", "Adi_entry",
              "Adi_entry","Adi_entry", "Adi_entry", "Adi_entry", "Adi_entry", "Adi_entry", "Adi_entry", "Adi_entry",
             "Adi_entry", "Adi_entry", "Adi_entry", "Adi_entry")
